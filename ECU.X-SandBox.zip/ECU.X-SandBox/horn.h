/* 
 * File:   horn.h
 * Author: Richard Johnson
 *
 * Created on May 26, 2015, 5:37 PM
 */

#ifndef HORN_H
#define	HORN_H

void RTD(int lenth);
void Boot(int lenth);
void Fault(int lenth);

#endif	/* HORN_H */

