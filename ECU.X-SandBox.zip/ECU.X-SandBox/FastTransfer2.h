/* 
 * File:   FastTransfer2.h
 * Author: Zac Kilburn
 *
 * Created on May 31, 2015, 2:09 PM
 */

#ifndef FASTTRANSFER2_H
#define	FASTTRANSFER2_H

#define polynomial 0x8C  //polynomial used to calculate crc

#endif	/* FASTTRANSFER2_H */

